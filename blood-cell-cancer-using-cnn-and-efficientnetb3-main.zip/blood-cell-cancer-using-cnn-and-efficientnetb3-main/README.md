# blood-cell-cancer-using-cnn-and-efficientnetb3
In this project we have taken a dataset from kaggal :https://www.kaggle.com/datasets/unclesamulus/blood-cells-image-dataset By the help of this dataset we are understand the blood cell cancer using the cnn model and efficientnetb3.In this project we have used useed the different graphs and confusion matrix and cnn model.
